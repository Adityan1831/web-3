document.getElementById('btn').onclick =function(){
    //alert('tak re lavdya')
   // confirm('Are you sure ypu want to procced')
    //prompt('Enter your name')
    //console.log(document.getElementById('x1'))
    var data = document.getElementById('x1').value;
    console.log(data)
    var msg="";
    // if(data==""){
    //     msg="please enter pincode";
    // }
    // else if(data.length!=6){
    //     msg="  pincode should be 6 digit"
    // }
    // else{
    //     msg="pincode is valid"
    // }
    var msg = date == ''
    ? "please enter pincode!"
    :data.length!=6
    ?"pincode should be 6 digit"
    : "pincode is valid";

    console.log(document.getElementById("result"))
    document.getElementById("result").innerHTML=msg

}

    console.log(document)
    console.log(typeof document)
console.log(document.getElementById('x2'));
console.log(document.getElementById('x3'));


    document.getElementById('x2').onclick=function(){
        console.log(document.body);
        document.body.style.background='lightgrey'
        document.body.style.color='black'
    }
    document.getElementById('x3').onclick=function(){
        console.log(document.body);
        document.body.style.background='black'
        document.body.style.color='white'
    }
